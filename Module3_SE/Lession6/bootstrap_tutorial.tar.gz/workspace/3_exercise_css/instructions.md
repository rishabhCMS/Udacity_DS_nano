# Instructions

Practice using CSS to style an html document. 

Go to the 3_exercise_css folder's index.html file and follow the TODO instructions for linking the style.css stylesheet to the index.html document. 
Then open the style.css document and complete all of the TODOs.

When you're finished, there are solution files in the solution folder.